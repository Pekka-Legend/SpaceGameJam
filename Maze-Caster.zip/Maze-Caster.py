import pygame
import math
import random
import time
import numpy
pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Raycaster")
going = True
x = 100
y = 100
font = pygame.font.SysFont("impact", 30)
titleFont = pygame.font.SysFont("impact", 100)


FOV = 15
RES = 12

wallColor = (100, 100, 100)
endColor = (255, 0, 0)
floorColor = (50, 50, 50)
skyColor = (0, 0, 0)


forward = False
score = 0
backward = False
sleft = False
sright = False
left = False
right = False
sup = False
sdown = False
direction = 94
timing = 0
rayx = 0
rayy = 0
raydir = 0
raylen = 0
distanceToWalls = 10

yLook = 0

timer = pygame.time.Clock()

screenNum = 0


class Text():
    def __init__(self, x, y, text, font):
        self.x = x
        self.y = y
        self.text = text
        self.font = font
    def Draw(self):
        text = self.font.render(self.text, True, (255,255,255))
        text_rect = text.get_rect()
        text_rect.x = self.x
        text_rect.y = self.y
        screen.blit(text, text_rect)

class Star():
    def __init__(self, x, y, radius):
        self.x = x
        self.y = y
        self.radius = radius
    def Draw(self):
        pygame.draw.circle(screen, (255, 255, 255), (self.x, self.y), self.radius)


def CastRay(rayAngle, rx):
    rayx = x
    rayy = y
    raydir = rayAngle
    raylen = 1000
    endx = 0
    endy = 0
    height = 0
    notEnd = True
    target = [0, 0]
    
    while target == [0, 0]:
        rayx += -math.sin(raydir) * 7
        rayy += math.cos(raydir) * 7
        for i in range(8):
            for j in range(12):
                if map[i][j] == "#" and rayx > j * 50 and rayx < j * 50 + 50 and rayy > i * 50 and rayy < i * 50 + 50 or map[i][j] == "E" and rayx > j * 50 and rayx < j * 50 + 50 and rayy > i * 50 and rayy < i * 50 + 50:
                    while rayx > j * 50 and rayx < j * 50 + 50 and rayy > i * 50 and rayy < i * 50 + 50:
                        rayx -= -math.sin(raydir) * 3
                        rayy -= math.cos(raydir) * 3
                    if math.sqrt((x - rayx)**2 + (x - rayy)**2) < raylen:
                        target = [rayx, rayy]
                        raylen = math.sqrt((rayx - x)**2 + (rayy - y)**2)
                    if map[i][j] == "#":
                        color = 0
                    if map[i][j] == "E":
                        color = 1

    height = 6000 / numpy.clip(raylen, 1, 100000000)
    height = numpy.clip(height, 0, 400)
    if color == 0:
        pygame.draw.line(screen, (numpy.clip(0 + (height * 2), 0, wallColor[0]), numpy.clip(0 + (height * 2), 0, wallColor[1]),numpy.clip(0 + (height * 2), 0, wallColor[2])), (rx, 300 - height - yLook), (rx, 300 + height - yLook), RES)
    elif color == 1:
        pygame.draw.line(screen, (numpy.clip(0 + (height * 2), 0, endColor[0]), numpy.clip(0 + (height * 2), 0, endColor[1]),numpy.clip(0 + (height * 2), 0, endColor[2])), (rx, 300 - height - yLook), (rx, 300 + height - yLook), RES)
    
    #pygame.draw.line(screen, (255, 255, 255), (x, y), target, 1)


map = [
    "############",
    "#          #",
    "#          #",
    "#          #",
    "#          #",
    "#          #",
    "#          #",
    "############",]

mapNum = 0


maps = [[
    "############",
    "#    #    E#",
    "#    #  ####",
    "#    #  #  #",
    "#       #  #",
    "#  ######  #",
    "#          #",
    "############",],

    [
    "############",
    "#          #",
    "#    ##E#  #",
    "#    #  #  #",
    "#       #  #",
    "#  ######  #",
    "#          #",
    "############",],

    [
    "######E#####",
    "#    #     #",
    "#    ####  #",
    "#    #     #",
    "#    #  ####",
    "#    #     #",
    "#          #",
    "############",],

    [
    "############",
    "#          #",
    "#    #     #",
    "#    ##    #",
    "#    ###   #",
    "#    #EE#  #",
    "#          #",
    "############",],

    [
    "############",
    "#    #E    #",
    "#    ##    #",
    "#     #    #",
    "#          #",
    "#          #",
    "#          #",
    "############",],

    [
    "############",
    "#      #   #",
    "#   #  #   #",
    "#####      #",
    "E   #      #",
    "#   #  #   #",
    "#      #   #",
    "############",],

    [
    "############",
    "#      #   #",
    "#          #",
    "#   ###### #",
    "#   #EE#   #",
    "#   #      #",
    "#         E#",
    "############",],

    [
    "############",
    "#    #     #",
    "#          #",
    "########   #",
    "E    #   ###",
    "#    ###   #",
    "#          #",
    "############",],

    [
    "############",
    "#          #",
    "#     ##   #",
    "#  #####   #",
    "#          #",
    "# ######## #",
    "#          E",
    "##########EE",],
    [
    "############",
    "#          #",
    "#  ##  ##  E",
    "#    ##    #",
    "# ##    ## #",
    "#  ######  #",
    "#          #",
    "##########E#",],

    [
    "##########EE",
    "#    ##    E",
    "#    ##    #",
    "# #  ##  # #",
    "# ##    ## E",
    "# ###  ### #",
    "#          #",
    "############",]

    ]





def SetEnd(mapNum):
    i = mapNum
    return i

mapNum = 0
map = maps[SetEnd(mapNum)]

gameTexts = [Text(30, 30, "Level " + str(score + 1), font), Text(30, 60, "Time Remaining: " + str(timing), font)]
titleTexts = [Text(135, 70, "Maze-Caster", titleFont), Text(250, 400, "Click Anywhere to Play", font), Text(30, 30, "Time: " + str(timing), font)]


while going:
    time = timer.tick(60)
    
    time /= 1000
    if screenNum == 1:
        timing += time
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            going = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                forward = True
            if event.key == pygame.K_s:
                backward = True
            if event.key == pygame.K_a:
                left = True
            if event.key == pygame.K_d:
                right = True
            if event.key == pygame.K_LEFT:
                sleft = True
            if event.key == pygame.K_RIGHT:
                sright = True
            if event.key == pygame.K_UP:
                sup = True
            if event.key == pygame.K_DOWN:
                sdown = True
                
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_w:
                forward = False
            if event.key == pygame.K_s:
                backward = False
            if event.key == pygame.K_a:
                left = False
            if event.key == pygame.K_d:
                right = False
            if event.key == pygame.K_LEFT:
                sleft = False
            if event.key == pygame.K_RIGHT:
                sright = False
            if event.key == pygame.K_UP:
                sup = False
            if event.key == pygame.K_DOWN:
                sdown = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            if screenNum == 0:
                screenNum = 1
                direction = 0
                x = 100
                y = 100
                yLook = 0
                score = 0
                mapNum = 0
                gameTexts[0] = Text(30, 30, "Level " + str(score + 1), font)
                timing = 0
    
    
    

    if screenNum == 1:
        if forward:
            x += -math.sin(direction) * 200 * time
            y += math.cos(direction) * 200 * time
        if backward:
            x -= -math.sin(direction) * 200 * time
            y -= math.cos(direction) * 200 * time
        if sleft:
            direction += 4
            x += -math.sin(direction) * 200 * time
            y += math.cos(direction) * 200 * time
            direction -= 4
        if sright:
            direction -= 4
            x += -math.sin(direction) * 200 * time
            y += math.cos(direction) * 200 * time
            direction += 4
        if sup:
            yLook -= 750 * time
        if sdown:
            yLook += 750 * time
            
        if right:
            direction += 2 * time
        if left:
            direction -= 2 * time
            
        screen.fill((0, 0, 0))
        
        
        pygame.draw.rect(screen, skyColor, (0, 0, 800, 300))

        yLook = numpy.clip(yLook, -250, 250)
        for i in range(8):
            for j in range(12):
                if map[i][j] == "#":
                    #pygame.draw.rect(screen, (50, 50, 50), (j * 50, i * 50, 51, 51))
                    if x - distanceToWalls> j * 50 and x - distanceToWalls< j * 50 + 50 and y > i * 50 and y < i * 50 + 50:
                        if x - distanceToWalls> j * 50 + distanceToWalls:
                            while x - distanceToWalls> j * 50 and x - distanceToWalls< j * 50 + 50 and y > i * 50 and y < i * 50 + 50:
                                x += 1
                    if x + distanceToWalls> j * 50 and x + distanceToWalls< j * 50 + 50 and y > i * 50 and y < i * 50 + 50:
                        if x + distanceToWalls < j * 50 + 25:
                            while x + distanceToWalls> j * 50 and x + distanceToWalls< j * 50 + 50 and y > i * 50 and y < i * 50 + 50:
                                x -= 1
                    if y - distanceToWalls> i * 50 and y - distanceToWalls< i * 50 + 50 and x > j * 50 and x < j * 50 + 50:
                        if y - distanceToWalls > i * 50 + 25:
                            while y - distanceToWalls> i * 50 and y -  distanceToWalls< i * 50 + 50 and x > j * 50 and x < j * 50 + 50:
                                y += 1
                    if y + distanceToWalls> i * 50 and y + distanceToWalls< i * 50 + 50 and x > j * 50 and x < j * 50 + 50:
                        if y + distanceToWalls < i * 50 + 25:
                            while y + distanceToWalls> i * 50 and y + distanceToWalls< i * 50 + 50 and x > j * 50 and x < j * 50 + 50:
                                y -= 1
                if map[i][j] == "E":
                    if x > j * 50 and x < j * 50 + 50 and y > i * 50 and y < i * 50 + 50:
                        mapNum += 1
                        if mapNum == len(maps) - 1:
                            screenNum = 0
                        map = maps[SetEnd(mapNum)]
                        x = 100
                        y = 100
                        direction = 94
                        score += 1
                        gameTexts[0] = Text(30, 30, "Level " + str(score + 1), font)


        raydirection = direction - 4 / (FOV / 2)
        rx = 0
        lines = round(800 / RES)
        for i in range(lines):
            CastRay(raydirection, rx)
            raydirection += (lines / FOV) / 200
            rx += RES

        for i in range(len(gameTexts)):
            gameTexts[i].Draw()
            gameTexts[1] = Text(30, 60, "Time: " + str(round(timing)), font)
    if screenNum == 0:
        screen.fill((0, 0, 0))
        titleTexts[2].text = "Time: " + str(round(timing))
        for i in range(len(titleTexts)):
            titleTexts[i].Draw()
    
    pygame.display.update()
pygame.quit()