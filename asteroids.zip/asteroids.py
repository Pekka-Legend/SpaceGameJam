import pygame
import math
import numpy
import random  
pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Asteroids")
going = True
x = 50
y = 50

font = pygame.font.SysFont("Times", 60)

forward = False
backward = False
left = False
shouldEnd = False
right = False
direction = 0
SPEED = .1
timer = pygame.time.Clock()
x_momentum = 0
y_momentum = 0


colors = [(255, 255, 255), (255, 255, 0), (255, 0, 0), (0, 255, 0), (0, 0, 255), (100, 100, 100), (0, 255, 255), (255, 0, 255)]
cindex = 0
scolor = colors[0]

class Bullet():
    def __init__(self, x, y, direc):
        self.x = x
        self.y = y
        self.direction = direc
        self.width = 5
        self.height = 5
    def Draw(self):
        pygame.draw.rect(screen, (255, 0, 0), (self.x, self.y, self.width, self.height))
    def Update(self):
        self.x += -math.sin(self.direction) * 10
        self.y += math.cos(self.direction) * 10
        

class Asteroid():
    def __init__(self, x, y, direc, radius):
        self.x = x
        self.y = y
        self.direction = direc
        self.radius = radius
        self.a = pygame.draw.circle(screen, (150, 150, 150), (self.x, self.y), self.radius)
    def Draw(self):
        a = pygame.draw.circle(screen, (150, 150, 150), (self.x, self.y), self.radius)
    def Update(self):
        self.x += -math.sin(self.direction) * 3
        self.y += math.cos(self.direction) * 3


class Text():
    def __init__(self, x, y, text):
        self.x = x
        self.y = y
        self.text = text
    def Draw(self):
        text = font.render(self.text, True, (255,255,255))
        text_rect = text.get_rect()
        text_rect.x = self.x
        text_rect.y = self.y
        screen.blit(text, text_rect)
        
resistance = .98


class Particle():
    def __init__(self, x, y, color, radius):
        self.x = x
        self.y = y
        self.velx = random.uniform(-4.0, 4.0)
        self.vely = random.uniform(-4.0, 2)
        self.color = color
        self.radius = radius
    def Draw(self):
        pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)
    def Update(self):
        
        self.velx *= resistance
        self.vely *= resistance
        
        self.radius -= .1
        
        self.x += self.velx * time * 80
        self.y += self.vely * time * 80
        


mousex = 0
mousey = 0
auto = False
particles = []
t = 0
score = 0
screenNum = 0
ticks = 180


title = Text(270, 100, "Asteroids")
start = Text(230, 400, "Click to Start")

bullets = [Bullet(-100, -100, 0)]
asteroids = []
while going:
    time = timer.tick(60)
    ticks += 1
    if ticks >= 300:
        asteroids.append(Asteroid(0, 0, random.randint(0, 360), random.randint(20, 80)))
        ticks = 0
    scoreText = Text(20, 20, str(score))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            going = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_w:
                forward = True
            if event.key == pygame.K_s:
                backward = True
            if event.key == pygame.K_a:
                left = True
            if event.key == pygame.K_d:
                right = True
            if event.key == pygame.K_SPACE:
                bullets.append(Bullet(x + -math.sin(direction) * 15, y+ math.cos(direction) * 15, direction))
            if event.key == pygame.K_UP:
                cindex += 1
                if cindex >= len(colors):
                    cindex = 0
                scolor = colors[cindex]
            if event.key == pygame.K_DOWN:
                cindex -= 1
                if cindex <= 0:
                    cindex = len(colors) - 1
                scolor = colors[cindex]
            
                
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_w:
                forward = False
            if event.key == pygame.K_s:
                backward = False
            if event.key == pygame.K_a:
                left = False
            if event.key == pygame.K_d:
                right = False
    if screenNum == 0 and pygame.mouse.get_pressed(3)[0]:
        screenNum = 1
        x = random.randint(100, 700)
        y = random.randint(100, 500)
        direction = 0
        asteroids = []
        ticks = 0
        bullets = []
        score = 0
        x_momentum = 0
        y_momentum = 0
        
    if screenNum == 0:
        particles = []
    
    
    
    if forward:
        x_momentum += -math.sin(direction) * SPEED
        y_momentum += math.cos(direction) * SPEED
    if backward:
        x_momentum -= -math.sin(direction) * SPEED
        y_momentum -= math.cos(direction) * SPEED
    if forward == False:
        if x_momentum > 0:
            x_momentum -= .05
        if x_momentum < 0:
            x_momentum += .05
        if y_momentum > 0:
            y_momentum -= .05
        if y_momentum < 0:
            y_momentum += .05

        
    time /= 1000
        
    x += x_momentum * time * 25
    y += y_momentum * time * 25
    
    
    if right:
        direction += 7 * time
    if left:
        direction -= 7 * time
    screen.fill((0, 0, 0))
    
    
    if x < 0:
        x = 800
    if x > 800:
        x = 0
    if y < 0:
        y = 600
    if y > 600:
        y = 0
    
    
    for i in range(len(bullets)):
        if screenNum == 1:
            bullets[i].Draw()
            bullets[i].Update()
            if bullets[i].x < 0:
                
                
                
                bullets.pop(i)
                break
            elif bullets[i].x > 800:
                
                
                    
                bullets.pop(i)
                break
            elif bullets[i].y < 0:
               
                bullets.pop(i)
                break
            elif bullets[i].y > 600:
                
                
                bullets.pop(i)
                break
    for i in range(len(particles)):
        particles[i].Update()
        particles[i].Draw()
    for i in range(len(particles)):
        try:
            if particles[i].radius <= 0:
                particles.pop(i)
        except IndexError:
            pass
    for i in range(len(asteroids)):
        if screenNum == 1:
            asteroids[i].Draw()
            asteroids[i].Update()
            if asteroids[i].x < 0:
                asteroids[i].x = 800
            if asteroids[i].x > 800:
                asteroids[i].x = 0
            if asteroids[i].y < 0:
                asteroids[i].y = 800
            if asteroids[i].y > 800:
                asteroids[i].y = 0
            
            if x > asteroids[i].x - asteroids[i].radius / 1 and x < asteroids[i].x + asteroids[i].radius / 1 and y > asteroids[i].y - asteroids[i].radius / 1 and y < asteroids[i].y + asteroids[i].radius / 1:
                screenNum = 0
            
            for j in range(len(bullets)):
                if bullets[j].x > asteroids[i].x - asteroids[i].radius / 1.2 and bullets[j].x < asteroids[i].x + asteroids[i].radius / 1.2 and bullets[j].y > asteroids[i].y - asteroids[i].radius / 1.2 and bullets[j].y < asteroids[i].y + asteroids[i].radius / 1.2:
                
                    if asteroids[i].radius > 25:
                        asteroids.append(Asteroid(asteroids[i].x + -math.cos(asteroids[i].direction) * 5, asteroids[i].y + math.cos(asteroids[i].direction) * 50, random.randint(0, 360), asteroids[i].radius / 2))
                        asteroids.append(Asteroid(asteroids[i].x + -math.cos(asteroids[i].direction) * -5, asteroids[i].y + math.cos(asteroids[i].direction) * -50, random.randint(0, 360), asteroids[i].radius / 2))
                
                    score += math.floor(asteroids[i].radius)
                
                    c = (random.randint(200, 255), random.randint(0, 50), random.randint(0, 50))
                    radius = random.uniform(1, 1.5)
                    dire = 0
                    for k in range(20):
                        color = (numpy.clip(c[0] + k * 5, 0, 255), numpy.clip(c[1] + k * 5, 0, 255), numpy.clip(c[2] + k * 5, 0, 255))
                    
                        color = pygame.Color(color)
                        particles.append(Particle(bullets[j].x, bullets[j].y, color, 10))
                        particles[len(particles) - 1].velx = numpy.sin(dire) * radius
                        particles[len(particles) - 1].vely = numpy.cos(dire) * radius
                        dire += 360 / 20
                    bullets.pop(j)
                    asteroids.pop(i)

                    shouldEnd = True
                    break
            if shouldEnd:
                break
        
    shouldEnd = False
    
    
    
    if screenNum == 1:
        pygame.draw.circle(screen, scolor, (x, y), 8)
        pygame.draw.line(screen, scolor, (x, y), (x + -math.sin(direction) * 15, y + math.cos(direction) * 15), 5)
    
    if screenNum == 0:
        title.Draw()
        start.Draw()
    scoreText.Draw()
    
    
    
    
    
    pygame.display.update()
pygame.quit()